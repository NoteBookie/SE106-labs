/*-----------------------------------------------------------------------
** File Name: Basic1.cpp
** ID:5130379059
** Name: Jin Jianian
** Created Time: 2014年11月21日 星期五 17时55分03秒
** ----------------------------------------------------------------------
*/
#include<iostream>
#include<string>
#include<map>
#include<vector>
#include<stdio.h>
#include<stdlib.h>

using namespace std;
map<string,int> vals;
bool IsWrong = false;
bool IsJmp = false;

string NoSpace(string test){
	string tested = "";
	for(int i = 0; i < test.size(); i++){
		if(test[i] != ' ') tested += test[i];
	}
	return tested;
}
string lower(string s){
	string temp = s;
	for(int i = 0; i < s.size();i++){
		if(s[i]>='A' && s[i] <= 'Z')
			temp[i] = s[i] - 'A' + 'a';
		else	temp[i] = s[i];
		//cout << temp[i];
	}
	//cout << endl;
	return temp;
}
bool valid(string s){
	for(int i = 0; i < s.size(); i++){
		if((s[i] < '0' || s[i] > '9') &&(s[i] != '-')) return false;
	}
	return true;
}
struct Tree{
	string var;
	Tree* Left;
	Tree* Right;
	Tree(string s){
		int pos = -1;
		int times = 0;  
		bool flag = true;
		/*first move away the useless brackets*/
		for(int i = 0; i < s.size()-2; i++){
			if(s[i] == '(') times++;
			if(s[i] == ')') times--;
			if(times == 0) {
				break;
			}
		}
		if(times) {
			s = s.substr(1,s.size() - 2);
			times = 0;
		}
		/*Then find the correct operand*/
		for(int i = s.size() - 1; i >= 0; i--){
			if(s[i] == ')' ) times++;
			if(s[i] == '(' ) times--;
			if(!times && ( s[i] == '-' || s[i] == '+')){
				pos = i;
				break;
			}
			if(!times && flag && ( s[i] == '*' || s[i] == '/')){
				pos = i;
				flag = false;
			}
		}	
		if(pos == -1){
			var = s;
			Left = NULL;
			Right = NULL;
		}else{
		/*do this recursively*/
			Left = new Tree(s.substr(0,pos));
			int length = s.size()-1-pos;
			Right = new Tree(s.substr(pos + 1, length));
			var = s[pos];
		}
	}
	void print_tree(){
	/*postorder traversal -- here comes the suffix expression*/
		if(Left != NULL)	Left->print_tree();
		if(Right != NULL)	Right->print_tree();
		cout << var << ' ';
	}
	int eval(const Tree* root){
		int i;
		int result;
		if(root->Left == NULL && root->Right == NULL){
			if(root->var[0] < '0' || root->var[0] > '9') {
				IsWrong = false;
				if(vals.find(lower(root->var)) == vals.end() ){
					cout << "VARIABLE NOT DEFINED\n"; 
					IsWrong = true;
				}
				else result = vals[lower(root->var)];
			}else result = atoi(root->var.c_str());
			//cout << result;
			return result;
		}
		switch(root->var[0]){
			case '+':
				return eval(root->Left) + eval(root->Right);
				break;
			case '-':
				return eval(root->Left) - eval(root->Right);
				break;
			case '*':
				return eval(root->Left) * eval(root->Right);
				break;
			case '/':
			{
				int left = eval(root->Left);
				int right = eval(root->Right);
				if(right == 0)  {cout << "DIVIDE BY ZERO\n";right = 1;IsWrong = true;}
				return left / right;
				break;
			}
		}
	}
};
class Interpreter{
private:
	vector<string> comments;
	map<int,string> codes;
public:
	Interpreter(){};
	void execve(){
		string s;
		while(getline(cin,s)){
			string n = lower(s);
			//cout<< n <<endl;
			if(n == "run") run();
			else if(n == "clear") clear();
			else if(n == "quit")  quit();
			else if(n == "list")  list();
			else if(n == "help")  help();
			else judge_if_now(s);
		}
		return;
	}
	void clear(){
		codes.clear();
		vals.clear();
	}
	void help(){
		cout << "Name:Jin Jianian\n" << "No:5130379059\n" << "Merry Christmas :D\n";
		return;
	}
	void list(){
		for(map<int,string>::iterator i = codes.begin();i != codes.end();i++){
			if(i->second != "") cout << i->first << " " << i->second << endl;
		}
		return;
	}
	void quit(){
		exit(0);
	}
	int expression(string s){
		string test = NoSpace(s);
		Tree* rpn = new Tree(test);
		return rpn->eval(rpn);	
	}
	bool boolean(string s){
		int i;
		for(i = 0; i < s.size(); i++){
			if(s[i] == '>' || s[i] == '<' || s[i] == '=')  break;
		}
		string s1 = NoSpace(s.substr(0,i));  	string s2 = NoSpace(s.substr(i+1));
		//cout << "s1: "<<s1 << endl << "s2: " << s2 <<endl;
		Tree* t1 = new Tree(s1);	        	Tree* t2 = new Tree(s2);
		int num = t1->eval(t1) - t2->eval(t2);
		//cout << "NUM: " << num << endl <<  s[i] << endl;
		if((num == 0 && s[i] == '=') || (num < 0 && s[i] == '<') || (num > 0 && s[i] == '>'))
			return true;
		return false;
	}
	void handler(string s){
		int i = 0;string key = "";
		while(i <= 2) key += s[i++];
		key = lower(key);
		if(key == "let"){
			int i;
			for(i = 4; i < s.size(); i++){
				if (s[i] == '=') break;
			}
			string var_name = lower(NoSpace(s.substr(4,i-4)))	;
			int var_value = expression(s.substr(i+1));
			vals[var_name] = var_value;
		}else if(key == "pri"){
			string p = s.substr(6);
			int ans = expression(p);
			if(!IsWrong)
				cout << expression(p) << endl;
			else return;
		}else if(key == "inp"){
			string var_name = s.substr(6);
			string s;
			int value;
			cout << " ? ";
			while(getline(cin,s)){
				if(valid(s)){
					value = atoi(s.c_str());
					break;
				}  
				cout << "INVALID NUMBER\n ? ";
			} 	 
			vals[var_name] = value;
		}else 
			return;
	}
	void judge_if_now(string s){
		int num = 0;
		string n = "", code = "";
		if(s[0] >= '0' && s[0] <='9'){
			for(int i = 0; i < s.size(); i++){
				if(s[i] >= '0' && s[i] <= '9')  n += s[i];
				else break;
			}
			num = atoi(n.c_str());
			//cout << num << endl;
			code = (s.size()!=n.size()) ? s.substr(n.size() + 1):"";
			//cout << code << endl;
			codes[num] = code;
		}
		else{
			handler(s);
		}
		return;
	}
	bool handler2(map<int,string>::iterator& iter,string s){
		int i = 0;string key = "";
		while(i <= 2) key += s[i++];
		key = lower(key);
		if(key == "let"){
			int i;
			for(i = 4; i < s.size(); i++){
				if (s[i] == '=') break;
			}
			string var_name = lower(NoSpace(s.substr(4,i-4)))	;
			int var_value = expression(s.substr(i+1));
			vals[var_name] = var_value;
		}else if(key == "pri"){
			string p = s.substr(5);
			int ans = expression(p);

			if(!IsWrong)
				cout << ans << endl;
			//else cout <<"WRONG"<<endl;
		}else if(key == "inp"){
			string var_name = s.substr(6);
			string s;
			int value;
			cout << " ? ";
			while(getline(cin,s)){
				if(valid(s)){
					value = atoi(s.c_str());
					break;
				}  
				cout << "INVALID NUMBER\n ? ";
			} 	 
			vals[var_name] = value;
			//cout << "ID: " << var_name << "     VAL: " << value << endl;
		}else if(key == "got"){
			string point = s.substr(5);
			int n = atoi(point.c_str());
			iter = codes.find(n);
			//cout << "GOTO: " << n <<endl;
			if(iter == codes.end()) {cout << "LINE NUMBER ERROR\n";return false;}
			//cout << "GOTO: " << iter->first << endl;
			if(iter != codes.begin()) iter--;
			else IsJmp = true;
		}else if(key == "if "){
			int i;
			for(i = 2; i < s.size()-4 ; i++){
				int j = i;string key = "";
				while(j <= i+3) key += s[j++];
				if(key == "THEN")
					break;
			}
			//cout << "check" << endl;
			string ocodes = s.substr(i+4);
			//cout <<"THEN:" << ocodes << endl;
			bool flag = boolean(s.substr(2,i-2));
			if(flag) {
				//cout <<"THEN:" << ocodes << endl;
				iter = codes.find(atoi(ocodes.c_str()));
				if(iter == codes.end()) {cout << "LINE NUMBER ERROR\n";return false;}
				if(iter != codes.begin()) 
					iter--;
				else IsJmp = true;
			}	
		}else if(key == "end") return false;
		return true;
	
	}
	void run(){
		//get codes from MAP-codes;
		map<int,string>::iterator iter = codes.begin();
		bool IsEnd = false;
		for(;iter != codes.end(); iter++){
			if(IsJmp) {iter--;IsJmp = false;}
			//cout << iter->first << endl;
			if(!handler2(iter,iter->second)) break;
		}
		//handler right now;
	}
};
int main(){
	Interpreter i;
	i.execve();
	return 0;
}
